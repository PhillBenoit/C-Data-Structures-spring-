// 269 - Homework 2 - poly class.cpp : Defines the entry point for the console application.
//

//#include "stdio.h"
#include "Poly.h"

int main()
{
	Poly<int> polyOne;
	polyOne.Poly(2, 2, 2);
	polyOne.print();
    return 0;
}

