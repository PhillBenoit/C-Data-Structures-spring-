//Poly.h

#ifdef  __POLY_H__
#define __POLY_H__


template <class T>
class Poly
{
public:
	T first, second, third;
	void Poly(T a, T b, T c);
	void print();
	//void add(Poly addend);
	//void multiply(Poly multiplier);
};

#endif // __POLY_H__