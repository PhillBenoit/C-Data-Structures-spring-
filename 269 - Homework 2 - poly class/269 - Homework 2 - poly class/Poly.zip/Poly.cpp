//Poly.cpp

#include "Poly.h"
#include "stdio.h"

template <class T>
class Poly
{
public:
	T first, second, third;
	
	void Poly::Poly(T a, T b, T c) {
		first = a;
		second = b;
		third = c;
	}
	
	void Poly::print() {
		printf("%dx� + %dx + %d\n", first, second, third);
	}
	
	//void Poly::add(Poly addend);
	//void Poly::multiply(Poly multiplier);
};